const express = require('express');
const PostController = require('./post.controller');
const authMiddleware = require('./../users/auth.middleware')
const postRouter = express.Router();

postRouter.post('/', authMiddleware.verifyAuthentication, PostController.createPost);
postRouter.get('/', PostController.getAllPosts);

postRouter.get('/:id', PostController.getPostById);
postRouter.put('/:id', authMiddleware.verifyAuthentication, PostController.updatePost);
postRouter.delete('/:id', 
    authMiddleware.verifyAuthentication, 
    authMiddleware.isAdmin,
    PostController.deletePost);

module.exports = postRouter;